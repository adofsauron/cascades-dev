//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wcol.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_WCOL1TYPE                   129
#define IDD_OPTIONDLG                   131
#define IDC_CATFILE_EDIT                1000
#define IDC_BROWSE1                     1001
#define IDC_QUERYEDIT                   1002
#define IDC_BROWSE2                     1003
#define IDC_CHECK1                      1004
#define IDC_FILE                        1004
#define IDC_CHECK2                      1005
#define IDC_WINDOW                      1005
#define IDC_CHECK3                      1006
#define IDC_PRUNING                     1006
#define IDC_CHECK4                      1007
#define IDC_CUCARD                      1007
#define IDC_COVE                        1008
#define IDC_GBLEPS                      1009
#define IDC_CMEDIT                      1010
#define IDC_BROWSE3                     1011
#define IDC_EPS_EDIT                    1012
#define IDC_FINALSSP                    1013
#define IDC_OPEN                        1014
#define IDC_SSP                         1015
#define IDC_EDIT1                       1016
#define IDC_EDIT2                       1017
#define IDC_EDIT3                       1018
#define IDC_RULESETEDIT                 1019
#define IDC_BROWSE4                     1020
#define IDC_EDIT4                       1021
#define IDC_RADIO_BATCH                 1022
#define IDC_RADIO_SINGLE                1023
#define IDC_QUERYEDIT2                  1024
#define IDC_BROWSE5                     1025
#define IDC_EDIT5                       1026
#define IDC_HALT                        1027
#define IDC_HALT_GRPSIZE                1028
#define IDC_HALT_WINSIZE                1029
#define IDC_HALT_IMPR                   1030
#define IDC_CHECK5                      1032
#define IDD_BEGIN                       32771
#define ID_BEGIN                        32771
#define IDD_MEMORY                      32772
#define ID_OPTION                       32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
